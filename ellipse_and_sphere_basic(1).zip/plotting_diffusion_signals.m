% load('signal_matrix_ellipse_sphere_parallel_diff_gradient.mat');

sph = signal_matrix_sphere_impermeable;
elp_imp = signal_matrix_ellipse_impermeable;
elp_perm = signal_matrix_ellipse_permeable;

% % clear signal_matrix_ellipse_permeable
% % clear signal_matrix_ellipse_impermeable
% % clear signal_matrix_sphere_impermeable

% % % % % % % % % % % % % % % % % % % % b_val = 100:50:1000;
% % % % % % % % % % % % % % % % % % % % N=10000;

diff_times = sph(1,2:end,1);
slope_sph = zeros(1,numel(diff_times));
slope_elp_imp = zeros(1,numel(diff_times));
slope_elp_perm = zeros(1,numel(diff_times));

for i=1:numel(diff_times)
   signal_sph = squeeze( abs(sph(i+1,i+1,:))/N );
   signal_elp_imp = squeeze( abs(elp_imp(i+1,i+1,:))/N );
   signal_elp_perm = squeeze( abs(elp_perm(i+1,i+1,:))/N );
   figure(1);hold on;subplot(3,2,i); plot(b_val,signal_sph,b_val,signal_elp_imp,b_val,signal_elp_perm, 'LineWidth', 3);
   figure(1);hold on;subplot(3,2,i);title(strcat('Diffusion time=',num2str(diff_times(i))));xlabel('b(s/mm^2)');ylabel('S(b)/S(0)')
   
   lh = legend('Impermeable  Sphere', 'Impermeable Ellipse', 'Permeable   Ellipse', 'Location', 'EastOutside');
   lh.FontWeight = 'Bold';
   lh.FontSize = 16;
   set(gca, 'FontSize', 15);
%    figure(1);hold on;subplot(3,2,i);legend(['Impermeable  Sphere';...
%                                             'Impermeable Ellipse';...
%                                             'Permeable   Ellipse']);
   p=polyfit(b_val*1e-3,2.303*log(signal_sph'),1);
   slope_sph(i) = -p(1);
   
   p=polyfit(b_val*1e-3,2.303*log(signal_elp_imp'),1);
   slope_elp_imp(i) = -p(1);
   
   p=polyfit(b_val*1e-3,2.303*log(signal_elp_perm'),1);
   slope_elp_perm(i) = -p(1);
end

%%
figure(2);hold on; plot(diff_times,slope_sph,diff_times,slope_elp_imp,diff_times,slope_elp_perm, 'LineWidth', 3); title('ADC vs Diffusion time');
figure(2);hold on; xlabel('Diffusion times(ms), \Delta'); ylabel('ADC(mu m^2/ms)');

lh = legend('Impermeable  Sphere', 'Impermeable Ellipse', 'Permeable   Ellipse', 'Location', 'EastOutside');
lh.FontWeight = 'Bold';
lh.FontSize = 16;
set(gca, 'FontSize', 15);
% figure(2);legend(['Impermeable  Sphere';...
%                   'Impermeable Ellipse';...
%                   'Permeable   Ellipse']);
% clear all
% Standard Equation of a 3D ellipse (x/a)^2+(y/b)^2+(z/c)^2 = 1
% f=(x/a)^2+(y/b)^2+(z/c)^2-1
% to develop the eccentricity of ellipse in 3D similar to 2D
% we define e1 = sqrt(1-(b/a)^2 ) and e2 = sqrt(1- (c/a)^2) ; a>b and a>c

%% ****** Defining 3D ellipse parameter*******
% % % % % % % % % % % % % R=15; % (mu m) radius of the sphere used for isotropic 
           % diffusion simulation
e1 = .8; % eccentricity between 'a' and 'b'
e2 = .8; % eccentricity between 'a' and 'c'

a = R./( sqrt(1-e1^2)*sqrt(1-e1^2) )^(1/3) ;  % (mu m)
% we are constructing the sphere and ellipse with same volume
% sphere volume,V = 4pi*(r^3)/3
% ellipsoid volume,V = 4pi*abc/3 = 4pi*a*a*sqrt(1-e1^2)*a*sqrt(1-e2^2)
b = a.*sqrt(1-e1^2); %ellipse parameter
c = a.*sqrt(1-e2^2);
% % % % % % % % % % % % N=10000; % number of particles
D=3; %(mu m)^2/ms
gamma = 2.675*10^8; %Gyromagnetic ratio rad /(T*s )
% % % % % % % % % % % % % % % % % % diff_times = 40:5:60;  % ms
% % % % % % % % % % % % % % % % % % dt=15; % time step(ms)
dr=sqrt(6*D*dt); % random walk step(mu m);
diff_steps = round(diff_times/dt); % diff_steps holds the random walk steps
% possible for various diff_times
% 'dt' can be considered as the time resolution . The diffusion sensitive
% gradients are considered to bge turned on for 'dt'

K = max(diff_steps);
N_time = length(diff_times); %Number of different diffusion times.
% % % % % % % % % % % % % % % % % % % b_val=100:50:1000;    % (s/ (mm)^2 )
signal_matrix = zeros (N_time+1,N_time +1,length(b_val) ); %Creates the output matrixes ,
% the number of gradient fields will be equal to length(diff_times). so we
% used N_time+1 in defining the row size of signal_matrix instead of
% defining with N_G+1

%% **********************************************   

%initial position
% cos_theta0 = 2*randn(1,N) -1 ;
% theta0 = acos(cos_theta0);
theta0 = pi*abs(rand(1,N));
phi0 = pi*rand(1,N);
dist0 = min([b c])*abs(rand(1,N))/5; % (1/5) factor is to gurantee that
% no particle is at the surface the beginning
x0 = dist0.*sin(theta0).*cos(phi0);
y0 = dist0.*sin(theta0).*sin(phi0);
z0 = dist0.*cos(theta0);
% Crashnr=0;

% % phase_x = zeros(N,N_time,numel(b_val));
% % phase_y = zeros(N,N_time,numel(b_val));
% % phase_z = zeros(N,N_time,numel(b_val));
signnal_temp = zeros(N,N_time,numel(b_val));

% % % % % % % % smoothing_iterations=5;

for q=1:smoothing_iterations
Crashnr=0;
parfor i=1:N
    x_pos = zeros(1,K);
    y_pos = x_pos;
    z_pos = x_pos;
    
    x_pos(1) = x0(i);
    y_pos(1) = y0(i);
    z_pos(1) = z0(i);
    
    for j=2:K
        
        dtheta = pi*abs(rand);
        dphi = 2*pi* rand;
        
        dx = dr*sin(dtheta)*cos(dphi);
        dy = dr*sin(dtheta)*sin(dphi);
        dz = dr*cos(dtheta);
        
        v = [dx dy dz]/dt;
        
        x_pos(j) = x_pos(j-1) + dx;
        y_pos(j) = y_pos(j-1) + dy;
        z_pos(j) = z_pos(j-1) + dz;
        
        xtemp = x_pos(j-1);
        ytemp = y_pos(j-1);
        ztemp = z_pos(j-1);
        
        bound_chk = 1;
        t_left = dt;
        % this is a control variable to make the program always check for
        % boundary cross for each step
        while bound_chk==1
        f_val = (x_pos(j)/a)^2 + (y_pos(j)/b)^2 + (z_pos(j)/c)^2;
        % 'f_val' variable checks for boundary cross. if it is less
        % than 1 then the particle is within the ellipse
        % f=(x/a)^2+(y/b)^2+(z/c)^2-1
        
        if f_val >=1
            
            Crashnr = Crashnr+1;
            % to find the point where the particle hits the surface first
            % we find the time of hitting the surface which will be less
            % than the time resolution dt. we have to solve a quadratic
            % equation
            % (x_pos(j-1)+v_x*t/a)^2+(y_pos(j-1)+v_y*t/b)^2+(z_pos(j-1)+v_z*t/c)^2 = 1 
            A= (v(1)/a)^2 + (v(2)/b)^2 + (v(3)/c)^2;
            B= 2*( (v(1)*xtemp/a^2) + (v(2)*ytemp/b^2) + (v(3)*ztemp/c^2) );
            C= (xtemp/a)^2 + (ytemp/b)^2 + (ztemp/c)^2 -1;
            t_hit = ( -B + sqrt( B^2 - 4*A*C ) )/ (2*A);
            t_hit = abs(t_hit);
%             if t_hit<0
%                 t_hit = ( -B - sqrt( B^2 - 4*A*C ) )/ (2*A);
%             end
            
            t_left = t_left - t_hit;
            if t_left<0 
                break; end
            hit_point = [xtemp ytemp ztemp] + v*t_hit;
            normal = 2*[hit_point(1)/a^2 hit_point(2)/b^2 hit_point(3)/c^2] ; 
            % Gradient of the equation of ellipse is 
            % [df/dx df/dy df/dz] = [2x/a^2 2y/b^2 2z/c^2] , for any point
            % (x0,y0,z0) this gradient at that point becomes 
            % [2x0/a^2 2y0/b^2 2z0/c^2] and this vector is parallel to the
            % normal to the ellipse surface drawn at (x0,y0,z0)
            normal= normal/norm(normal);
            v_new = v - 2*dot(v,normal)*normal; % reflected velocity eqn 2.19
            % masters thesis
            x_pos(j) = hit_point(1) + v_new(1)*t_left;
            y_pos(j) = hit_point(2) + v_new(2)*t_left;
            z_pos(j) = hit_point(3) + v_new(3)*t_left;
            
            v=v_new;
            
            xtemp = hit_point(1);
            ytemp = hit_point(2);
            ztemp = hit_point(3);
            
        else bound_chk = 0;
        end
        end
    end
    
   
% % % % % % %     for g=1:K
% % % % % %         figure(i);
% % % % % %         xlim([-1.5*a 1.5*a]);
% % % % % %         ylim([-1.5*b 1.5*b]);
% % % % % %         zlim([-1.5*c 1.5*c]);
% % % % % %         plot3(x_pos,y_pos,z_pos);
% % % % % %         pause(.5);
% % % % % % %     end
%   temp1=G_x;
  temp2=diff_times;
  temp3=diff_steps;
  temp4=b_val;
  temp_signal = zeros(N_time,numel(b_val));
  
  for p=1:numel(b_val)
       if b_val(p)~=0
        G = ( (diff_times-dt/3).*(10^-3)*(gamma^2)*((dt*10^-3)^2 ))/( b_val(p)*1e6 ) ;  
        G=G.^(-1/2);
% G is the gradient row vector for the respective b-value(b(i)) and the
% diffusion times vector
        G=G*1e3; %Gradient strength [mT/m]
      else
          G=zeros(1,numel(diff_times));
      end
      if strcmp(diff_grad_dir,'par')
        G_x = G; % assuming equal diffusion sensitive gradients are
% applied in all three dimensions. G^2 = G_x^2+G_y^2+G_z^2= 3*G_x^2
        G_y = zeros(1,numel(diff_times));
        G_z = zeros(1,numel(diff_times));
      elseif strcmp(diff_grad_dir,'perp')
        G_x = zeros(1,numel(diff_times)); % assuming equal diffusion sensitive gradients are
% applied in all three dimensions. G^2 = G_x^2+G_y^2+G_z^2= 3*G_x^2
        G_y = sqrt(G/2);
        G_z = sqrt(G/2);
      end
    for Nr = 1 : N_time
        Y_x = G_x(Nr)*dt*gamma;  % 'q' in eqn 2.11
        Y_y = G_y(Nr)*dt*gamma;
        Y_z = G_z(Nr)*dt*gamma;

%******* I : +Gfirst step , -Glast step*****
        d_phase_x= [Y_x*x_pos(1) -Y_x*x_pos(diff_steps(Nr))] ; %eqn 2.10
        d_phase_y = [Y_y*y_pos(1) -Y_y*y_pos(diff_steps(Nr))] ;
        d_phase_z = [Y_z*z_pos(1) -Y_z*z_pos(diff_steps(Nr))] ;
%       phase_1(n , Nr) = sum( d_phase)*10^-12;

% % % %         phase_x(i, Nr, p) = sum( d_phase_x)*10^-12;
% % % %   % unit of Y_x is mT.ms.rad/(T.meter) ; unit of x_pos is (mu m). So in
% % % %   % order to adjust scale 10^-12 is multiplied
% % % %         phase_y(i, Nr, p ) = sum( d_phase_y)*10^-12;
% % % %         phase_z(i, Nr, p ) = sum( d_phase_z)*10^-12;
         temp_signal(Nr,p) = exp(-1i*sum( d_phase_x+d_phase_y+d_phase_z )*1e-12);
    end
  end
    signal_temp(i,:,:) = temp_signal;

end

%    phase_chng= phase_x+phase_y+phase_z;

string1 = ['Number of collitions : ' , num2str(Crashnr) ] ;
disp(string1);

for p=1:numel(b_val)
% % % %     signal = sum(exp(-sqrt(-1i)*phase_chng)) ; %Computes resulting phase
% exp(-sqrt(-1)*phase) results in a N x N_time_N_G matrix. sum function
% adds all the row elements to give a 1 x N_time_N_G vector. each elements
% of 'signal' vector represents the total observed signal from all the
% particles for a particular diffusion time and gradient vlaue.
    signal = sum(signal_temp(:,:,p));
    if b_val(p)~=0
        G = ( (diff_times-dt/3).*(10^-3)*(gamma^2)*((dt*10^-3)^2 ))/( b_val(p)*1e6 ) ;  
        G=G.^(-1/2);
% G is the gradient row vector for the respective b-value(b(i)) and the
% diffusion times vector
        G=G*1e3; %Gradient strength [mT/m]
      else
          G=zeros(1,numel(diff_times));
    end 
    signal_matrix(2:end ,1,p) = G ; %first column and first row
    signal_matrix(1,2:end,p) = diff_times ; %specifies gradient strength

 %????? Saves all phases into the matrix ?????
% A = 1 ;
% B = N_time ;
    for i = 2 :N_time+1
        signal_matrix(i,i,p) = signal_matrix(i,i,p)+signal(i-1);
%  signal_matrix(i,2:end,o) = signal(A:B);
 % the variable signal is supposed to be a matrix. But it is indexed as a 
 % vector..??? ...raiyan
 % signal_matrix(2:end,1) has all the gradient values.
 % signal_matrix(1,2:end) has different diff_times used
 % signal_matrix contains signals relating to different gradients at the 
 % same diff_times along any column(column2 to the last column has signals)
 % the rows contains the signals relating to different diff_times for a
 % fixed gradient(row2 to to the last row).
 % the first row and the first column does not have any signal values.
 
%  A = A + N_time ;
%  B = B + N_time ;
    end
%????????????????????????????????????????????

% signal = signal_matrix (:, : , o);
end

end

signal_matrix(2:end,2:end,:) = signal_matrix(2:end,2:end,:)/smoothing_iterations;
signal_matrix_ellipse_impermeable = signal_matrix;
    

anisotropic3D_diffusion_Ellipse_permeable